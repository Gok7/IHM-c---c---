/* 
 * File:   C_CADRE.h
 * Author: Administrateur
 *
 * Created on 5 décembre 2013, 08:49
 */

#ifndef _C_CADRE_H
#define	_C_CADRE_H

#include "ui_C_CADRE.h"
#include "C_DATA.h"

class C_CADRE : public QMainWindow {
    Q_OBJECT
public:
    C_CADRE();
    virtual ~C_CADRE();
    void Set_Donnee_Partagee(C_DATA* P_Donne_Partagee);
    
    Ui::Fenetre widget;
    
    protected :
        C_DATA* Donne_Partagee;
       
     protected slots :
            void Quand_On_Change_Sliders();
};

#endif	/* _C_CADRE_H */
