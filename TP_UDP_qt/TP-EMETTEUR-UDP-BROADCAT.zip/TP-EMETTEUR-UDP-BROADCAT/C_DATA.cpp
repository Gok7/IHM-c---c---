/* 
 * File:   C_DATA.cpp
 * Author: Administrateur
 * 
 * Created on 28 novembre 2013, 14:04
 */

#include "C_DATA.h"

C_DATA::C_DATA() {
    Valeur_1=0;
    Valeur_2=0;
}

void C_DATA::Ecrire_Valeurs(int P_Valeur_1, int P_Valeur_2)
{
    Verrou.P();
      Valeur_1 = P_Valeur_1;
      Valeur_2 = P_Valeur_2;
    Verrou.V();
}
//------------------------------------------------------------------------------
void C_DATA::Ecrire_Valeur_1(int P_Valeur_1)
{
    Verrou.P();
      Valeur_1 = P_Valeur_1;
    Verrou.V();
}
//------------------------------------------------------------------------------
void C_DATA::Ecrire_Valeur_2(int P_Valeur_2)
{
    Verrou.P();
      Valeur_2 = P_Valeur_2;
    Verrou.V();
}
//------------------------------------------------------------------------------

void C_DATA::Lire_Valeurs(int* P_Valeur_1, int* P_Valeur_2)
{
    Verrou.P();
      *P_Valeur_1=Valeur_1;
      *P_Valeur_2=Valeur_2;
    Verrou.V(); 
}
