/*
 * File:   C_CADRE.cpp
 * Author: Administrateur
 *
 * Created on 5 décembre 2013, 08:49
 */

#include "C_CADRE.h"

C_CADRE::C_CADRE() {
    widget.setupUi(this);
}

C_CADRE::~C_CADRE() {
}
//------------------------------------------------------------------------

void C_CADRE::Set_Donnee_Partagee(C_DATA* P_Donne_Partagee)
{
    Donne_Partagee = P_Donne_Partagee;
}

//------------------------------------------------------------------------

void C_CADRE::Quand_On_Change_Sliders()
{
 int L_Valeur_Slider_1 = widget.Le_Slider_1->value();
 int L_Valeur_Slider_2 = widget.Le_Slider_2->value();
 
 Donne_Partagee->Ecrire_Valeurs(L_Valeur_Slider_1, L_Valeur_Slider_2);
 
 QString L_Chaine("Valeurs : ");
 
 L_Chaine +=  QString::number(L_Valeur_Slider_1,10);
 L_Chaine +=  ", ";
 L_Chaine +=  QString::number(L_Valeur_Slider_2,10);
 
 
 widget.Liste_Infos->addItem(L_Chaine);
 widget.Liste_Infos->scrollToBottom();
 
}