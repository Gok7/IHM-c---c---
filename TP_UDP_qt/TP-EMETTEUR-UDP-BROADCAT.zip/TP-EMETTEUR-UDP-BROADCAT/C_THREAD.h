/* 
 * File:   C_THREAD.h
 * Author: Administrateur
 *
 * Created on 14 novembre 2013, 10:43
 */

#ifndef C_THREAD_H
#define	C_THREAD_H

#include <windows.h>

class C_THREAD {
public:
    C_THREAD();
    
    void Reveille_Toi();
    void Endors_Toi();
    void Termine_Toi(DWORD P_Code=0);
    HANDLE Get_Handle();
    
    void Set_Affinite(DWORD P_Coeur);
    void Set_Priotite(DWORD P_Priorite);
    DWORD Synchronisation_Avec_Mort(DWORD P_Time_Out = INFINITE);

protected :
   static DWORD Fonction_Thread(C_THREAD* P_Info);
   virtual void Run()=0;
 
    HANDLE H_Thread;
    DWORD  TID;
};

#endif	/* C_THREAD_H */

