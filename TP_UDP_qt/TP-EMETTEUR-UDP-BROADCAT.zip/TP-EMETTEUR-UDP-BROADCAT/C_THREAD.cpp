/* 
 * File:   C_THREAD.cpp
 * Author: Administrateur
 * 
 * Created on 14 novembre 2013, 10:43
 */

#include "C_THREAD.h"

C_THREAD::C_THREAD() 
{
    H_Thread = CreateThread(NULL, 0, (LPTHREAD_START_ROUTINE)Fonction_Thread , 
                            this, CREATE_SUSPENDED,&TID);
    
    if (H_Thread==NULL) throw ("C_THREAD : Erreur CreateThread"); 
}

//------------------------------------------------------------------------------
DWORD C_THREAD::Fonction_Thread(C_THREAD* P_Objet)
{
    P_Objet-> Run();
    return 0;
}

//------------------------------------------------------------------------------
void C_THREAD::Reveille_Toi()
{
    if (H_Thread) ResumeThread(H_Thread);
}
//------------------------------------------------------------------------------
void C_THREAD::Endors_Toi()
{
    if (H_Thread) SuspendThread(H_Thread);
}
//------------------------------------------------------------------------------
void C_THREAD::Termine_Toi(DWORD P_Code)
{
   if (H_Thread) TerminateThread(H_Thread, P_Code); 
}
//------------------------------------------------------------------------------
HANDLE C_THREAD::Get_Handle()
{
    return H_Thread;
}
//------------------------------------------------------------------------------
void C_THREAD::Set_Affinite(DWORD P_Coeur)
{
   if (H_Thread) SetThreadAffinityMask(H_Thread, P_Coeur);  
}
//------------------------------------------------------------------------------
void C_THREAD::Set_Priotite(DWORD P_Priorite)
{
    if (H_Thread) SetThreadPriority(H_Thread,P_Priorite); 
}
//------------------------------------------------------------------------------
DWORD C_THREAD::Synchronisation_Avec_Mort(DWORD P_Time_Out)
{
 return WaitForSingleObject(H_Thread,P_Time_Out);
}