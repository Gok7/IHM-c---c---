/********************************************************************************
** Form generated from reading UI file 'C_CADRE.ui'
**
** Created by: Qt User Interface Compiler version 5.1.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_C_CADRE_H
#define UI_C_CADRE_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QListWidget>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenu>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QProgressBar>
#include <QtWidgets/QSlider>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Fenetre
{
public:
    QAction *action_Quitter;
    QWidget *centralwidget;
    QSlider *Le_Slider_1;
    QProgressBar *Barre_Progression_1;
    QProgressBar *Barre_Progression_2;
    QSlider *Le_Slider_2;
    QListWidget *Liste_Infos;
    QMenuBar *menubar;
    QMenu *menu_Fichier;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *Fenetre)
    {
        if (Fenetre->objectName().isEmpty())
            Fenetre->setObjectName(QStringLiteral("Fenetre"));
        Fenetre->resize(357, 310);
        action_Quitter = new QAction(Fenetre);
        action_Quitter->setObjectName(QStringLiteral("action_Quitter"));
        centralwidget = new QWidget(Fenetre);
        centralwidget->setObjectName(QStringLiteral("centralwidget"));
        Le_Slider_1 = new QSlider(centralwidget);
        Le_Slider_1->setObjectName(QStringLiteral("Le_Slider_1"));
        Le_Slider_1->setGeometry(QRect(30, 10, 19, 251));
        Le_Slider_1->setMaximum(100);
        Le_Slider_1->setOrientation(Qt::Vertical);
        Le_Slider_1->setTickPosition(QSlider::TicksAbove);
        Barre_Progression_1 = new QProgressBar(centralwidget);
        Barre_Progression_1->setObjectName(QStringLiteral("Barre_Progression_1"));
        Barre_Progression_1->setGeometry(QRect(60, 10, 21, 251));
        Barre_Progression_1->setValue(0);
        Barre_Progression_1->setTextVisible(false);
        Barre_Progression_1->setOrientation(Qt::Vertical);
        Barre_Progression_2 = new QProgressBar(centralwidget);
        Barre_Progression_2->setObjectName(QStringLiteral("Barre_Progression_2"));
        Barre_Progression_2->setGeometry(QRect(150, 10, 21, 251));
        Barre_Progression_2->setValue(0);
        Barre_Progression_2->setTextVisible(false);
        Barre_Progression_2->setOrientation(Qt::Vertical);
        Le_Slider_2 = new QSlider(centralwidget);
        Le_Slider_2->setObjectName(QStringLiteral("Le_Slider_2"));
        Le_Slider_2->setGeometry(QRect(120, 10, 19, 251));
        Le_Slider_2->setMaximum(100);
        Le_Slider_2->setOrientation(Qt::Vertical);
        Le_Slider_2->setTickPosition(QSlider::TicksAbove);
        Liste_Infos = new QListWidget(centralwidget);
        Liste_Infos->setObjectName(QStringLiteral("Liste_Infos"));
        Liste_Infos->setGeometry(QRect(200, 10, 141, 251));
        QFont font;
        font.setFamily(QStringLiteral("Vijaya"));
        font.setPointSize(12);
        Liste_Infos->setFont(font);
        Liste_Infos->setStyleSheet(QLatin1String("background-color: rgb(219, 234, 255)\n"
""));
        Fenetre->setCentralWidget(centralwidget);
        menubar = new QMenuBar(Fenetre);
        menubar->setObjectName(QStringLiteral("menubar"));
        menubar->setGeometry(QRect(0, 0, 357, 21));
        menu_Fichier = new QMenu(menubar);
        menu_Fichier->setObjectName(QStringLiteral("menu_Fichier"));
        Fenetre->setMenuBar(menubar);
        statusbar = new QStatusBar(Fenetre);
        statusbar->setObjectName(QStringLiteral("statusbar"));
        Fenetre->setStatusBar(statusbar);

        menubar->addAction(menu_Fichier->menuAction());
        menu_Fichier->addAction(action_Quitter);

        retranslateUi(Fenetre);
        QObject::connect(action_Quitter, SIGNAL(triggered()), Fenetre, SLOT(close()));
        QObject::connect(Le_Slider_2, SIGNAL(valueChanged(int)), Barre_Progression_2, SLOT(setValue(int)));
        QObject::connect(Le_Slider_1, SIGNAL(valueChanged(int)), Barre_Progression_1, SLOT(setValue(int)));
        QObject::connect(Le_Slider_1, SIGNAL(valueChanged(int)), Fenetre, SLOT(Quand_On_Change_Sliders()));
        QObject::connect(Le_Slider_2, SIGNAL(valueChanged(int)), Fenetre, SLOT(Quand_On_Change_Sliders()));

        QMetaObject::connectSlotsByName(Fenetre);
    } // setupUi

    void retranslateUi(QMainWindow *Fenetre)
    {
        Fenetre->setWindowTitle(QApplication::translate("Fenetre", "Emetteur UDP BROADCAST ", 0));
        action_Quitter->setText(QApplication::translate("Fenetre", "&Quitter", 0));
        menu_Fichier->setTitle(QApplication::translate("Fenetre", "&Fichier", 0));
    } // retranslateUi

};

namespace Ui {
    class Fenetre: public Ui_Fenetre {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_C_CADRE_H
