/* 
 * File:   C_DATA.h
 * Author: Administrateur
 *
 * Created on 28 novembre 2013, 14:04
 */

#ifndef C_DATA_H
#define	C_DATA_H

#include "C_SECTION_CRITIQUE.h"


class C_DATA {
public:
    C_DATA();

    void Ecrire_Valeurs(int P_Valeur_1, int P_Valeur_2);
    void Ecrire_Valeur_1(int P_Valeur_1);
    void Ecrire_Valeur_2(int P_Valeur_2);
    
    void Lire_Valeurs(int* P_Valeur_1, int* P_Valeur_2);
    
protected :
    int Valeur_1;
    int Valeur_2;
    C_SECTION_CRITIQUE Verrou;
    
};

#endif	/* C_DATA_H */

