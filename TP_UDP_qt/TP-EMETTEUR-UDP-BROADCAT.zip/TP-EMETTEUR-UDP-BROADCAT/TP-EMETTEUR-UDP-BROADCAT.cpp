/*
 * File:   TP-EMETTEUR-UDP-BROADCAT.cpp
 * Author: Administrateur
 *
 * Created on 5 décembre 2013, 08:47
 */

#include <QApplication>

#include "C_CADRE.h"
#include "C_DATA.h"
#include "C_EMETTEUR_UDP.h"


 


 
 //=============================================================================
 void Init_DLL_Socket() {
    WSADATA L_Info_DLL;
    WSAStartup(MAKEWORD(2, 0), &L_Info_DLL);
}

//---------------------------------------------------------

void Fin_DLL_Socket() {
    WSACleanup();
}
 //=============================================================================

int main(int argc, char *argv[]) {

Init_DLL_Socket();

    QApplication app(argc, argv);
    C_CADRE Le_Cadre;
    
    C_DATA Info_Partagee;
    C_EMETTEUR_UDP Emetteur_UDP; 
    
    Emetteur_UDP.Set_Donnee_Partagee(&Info_Partagee);
    
    Le_Cadre.Set_Donnee_Partagee(&Info_Partagee);
    
    Le_Cadre.show();
    
    Emetteur_UDP.Reveille_Toi();
 

    int L_Resultat = app.exec();
    Emetteur_UDP.Arrete_Toi();
    Emetteur_UDP.Synchronisation_Avec_Mort();
    
    Fin_DLL_Socket();
    
    return L_Resultat;
}
