/* 
 * File:   C_EMETTEUR_UDP.h
 * Author: Administrateur
 *
 * Created on 28 novembre 2013, 14:13
 */

#ifndef C_EMETTEUR_UDP_H
#define	C_EMETTEUR_UDP_H

#include "C_THREAD.h"

#include "C_DATA.h"


#define PORT_COMMUNICATION_UDP 9900
#define ADRESSE_DESTINATION "255.255.255.255"


class C_EMETTEUR_UDP: public C_THREAD {
public:
    C_EMETTEUR_UDP();

     ~C_EMETTEUR_UDP();
     void Set_Donnee_Partagee( C_DATA* P_Donnee);
     void Arrete_Toi();
protected :
    void Run();
    volatile long Fin_Thread;
    C_DATA* La_Donnee_Partagee;
    
    void Creation_Socket();
        SOCKET      Socket_Client; 
        sockaddr_in Info_Process_Distant; 
};

#endif	/* C_EMETTEUR_UDP_H */

