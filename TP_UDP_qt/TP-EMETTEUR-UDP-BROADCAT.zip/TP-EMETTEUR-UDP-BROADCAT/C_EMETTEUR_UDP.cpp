/* 
 * File:   C_EMETTEUR_UDP.cpp
 * Author: Administrateur
 * 
 * Created on 28 novembre 2013, 14:13
 */

#include "C_EMETTEUR_UDP.h"

#include <iostream>
using namespace std;

C_EMETTEUR_UDP::C_EMETTEUR_UDP() {
    Fin_Thread=0;
    La_Donnee_Partagee=NULL;
}



C_EMETTEUR_UDP::~C_EMETTEUR_UDP() {
}

void C_EMETTEUR_UDP::Arrete_Toi()
{
    InterlockedIncrement(&Fin_Thread);
}

void C_EMETTEUR_UDP::Set_Donnee_Partagee(C_DATA* P_Donnee)
{
    La_Donnee_Partagee = P_Donnee;
}

void C_EMETTEUR_UDP::Creation_Socket()
{


   Socket_Client= socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP ); 
   if (Socket_Client == INVALID_SOCKET) throw ("C_EMETTEUR_UDP::Execute - socket");
  
  Info_Process_Distant.sin_family = AF_INET;
  Info_Process_Distant.sin_port=htons(PORT_COMMUNICATION_UDP);
  Info_Process_Distant.sin_addr.S_un.S_addr = inet_addr(ADRESSE_DESTINATION);
  
  bool L_Broadcast=true;
  int L_Resultat=setsockopt(Socket_Client,SOL_SOCKET, SO_BROADCAST,
                (char*)&L_Broadcast,sizeof(L_Broadcast));
  if (L_Resultat ==SOCKET_ERROR) throw ("C_EMETTEUR_UDP::Execute - setsockopt SO_BROADCAST"); 

}


void C_EMETTEUR_UDP::Run()
{

 int L_Valeurs[2];
 int L_Ancienne_Valeurs[2];
 int L_Taille;

    if (La_Donnee_Partagee) {
        
        Creation_Socket();
        
        La_Donnee_Partagee->Lire_Valeurs(&L_Ancienne_Valeurs[0], &L_Ancienne_Valeurs[0]);
        
      while (Fin_Thread ==0 ){
        La_Donnee_Partagee->Lire_Valeurs(&L_Valeurs[0], &L_Valeurs[1]);
        if ((L_Valeurs[0] != L_Ancienne_Valeurs[0]) || (L_Valeurs[1] != L_Ancienne_Valeurs[1])) {
            L_Ancienne_Valeurs[0] = L_Valeurs[0];
            L_Ancienne_Valeurs[1] = L_Valeurs[1];
            cout<<"                   "<<L_Valeurs[0]<<", "<<L_Valeurs[1]<<endl;
            
            
             L_Taille= sendto(Socket_Client, (char*) L_Valeurs ,  sizeof(L_Valeurs) , 
                        0,(sockaddr*)&Info_Process_Distant, sizeof(Info_Process_Distant ) );
       
             if (L_Taille != sizeof(L_Valeurs) )Fin_Thread=1;
             
        }
        Sleep(100);
        
      }
      closesocket(Socket_Client);
    }
 
  
}